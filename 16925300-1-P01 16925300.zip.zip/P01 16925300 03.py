# NIM/Nama : 16925300/Nadiya Aliya Nanda
# Tanggal : 1 Oktober 2025
# Deskripsi : Menghitung Daftar Belanja Nona Sal

''' Nona Sal diminta untuk menghitung kompleksitas algoritma pada hasil praktikumnya. Algoritma yang ia
buat memiliki n operasi dasar dan setiap operasi membutuhkan waktu t mikrodetik. Namun ada overhead
sistem sebesar o persen dari total waktu eksekusi. Jika processor berjalan pada frekuensi f GHz, tentukan
jumlah clock cycle yang dibutuhkan dan efisiensi algoritma dalam operasi per detik!
Petunjuk:
• Waktu total = waktu dasar + overhead
• 1 GHz = 1000 MHz, 1 mikrodetik = 0.000001 detik
• Clock cycle = waktu × frekuensi (perhatikan konversi satuan!)
• Efisiensi = jumlah operasi ÷ waktu total'''

#input
jml_opr= int(input("Masukkan jumlah operasi:"))
wkt_per_opr= int(input("Masukkan waktu per operasi ( mikrodetik ):"))
wkt_ovr= int(input("Masukkan overhead (persen):"))
fr= int(input("Masukkan frekuensi (GHz):"))


#proses 
cc= fr*jml_opr*(wkt_per_opr + (wkt_per_opr*(wkt_ovr/100)))*1000
efi = jml_opr/(wkt_per_opr*(wkt_ovr/100))*1000

#output
print("Clock cycle yang dihasilkan adalah"  + " " + str(cc)  + " " + "cycle", end="")
print(" dengan efisiensi" + " " + str(efi)  + " " + "operasi/detik.")

