# NIM/Nama : 16925300/Nadiya Aliya Nanda
# Tanggal : 1 Oktober 2025
# Deskripsi : Menghitung Daftar Belanja Nona Sal

''' Nona Sal sedang membuat pizza yang membutuhkan f gram tepung, c gram keju, dan s ml saus. Jika satu
pizza dapat dimakan oleh k orang, tentukan berapa banyak bahan lain yang dibutuhkan untuk sebuah pesta
dengan jumlah tamu n!
Catatan: Dapat dipastikan bahwa n habis dibagi k.'''

'''Masukkan jumlah tepung untuk 1 pizza (dalam gram): 10
Masukkan jumlah keju untuk 1 pizza (dalam gram): 20
Masukkan jumlah saus untuk 1 pizza (dalam ml): 30
Masukkan jumlah orang per pizza : 3
Masukkan jumlah tamu: 30
Nona Sal perlu membeli 100 gram tepung , 200 gram keju , dan 300 ml saus.'''

#input
jmlh_tpng= int(input("Masukkan jumlah tepung untuk 1 pizza (dalam gram):"))
jmlh_keju= int(input("Masukkan jumlah keju untuk 1 pizza (dalam gram):"))
jmlh_saus= int(input("Masukkan jumlah saus untuk 1 pizza (dalam ml):"))
jmlh_org= int(input("Masukkan jumlah orang untuk 1 pizza:"))
jmlh_tamu= int(input("Masukkan jumlah tamu:"))

#proses 
x= jmlh_tamu/jmlh_org 
a= jmlh_tpng*x
b= jmlh_keju*x
c= jmlh_saus*x

#output

print("Nona Sal perlu membeli" + " " + str(a) + " " + "tepung," + str(b) + " " + "gram keju, dan" + " " + str(c) + " " + "ml saus.")
 + " " + 