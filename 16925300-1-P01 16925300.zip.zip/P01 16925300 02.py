
# NIM/Nama : 16925300/Nadiya Aliya Nanda
# Tanggal : 1 Oktober 2025
# Deskripsi : Menghitung Daftar Belanja Nona Sal

''' Tuan Vin adalah seorang gamer. Ia sangat senang memainkan video gim GachaNow!, video gim yang membutuhkan keberuntungan tingkat tinggi bagi pemainnya untuk mengoleksi karakter-karakter dengan rarity yang
berbeda. Pemain bisa mendapatkan karakter lewat draw. Karakter dibagi menjadi 3 tipe dengan persentase
atau chance untuk mendapatkannya sebagai berikut.
• Karakter common dengan persentase 70% (dibulatkan ke bawah).
• Karakter rare dengan persentase 20% (dibulatkan ke bawah).
• Karakter super rare sebanyak jumlah draw dikurangi banyak karakter common dan rare yang didapatkan.
Developer video gim yang berbaik hati memberikan bonus kepada pemain. Pemain akan mendapatkan karakter
rare untuk setiap 10 karakter common yang ia dapatkan. Pemain akan mendapatkan karakter super rare untuk
setiap 10 karakter rare yang ia dapatkan, baik itu yang didapat lewat draw atau bonus dari developer. Developer
memberikan kuota bonus untuk pemain maksimal 5 karakter rare dan 3 karakter super rare.
Tentukan ekspektasi banyaknya karakter yang bisa didapatkan oleh Tuan Vin berdasarkan jumlah draw yang
ia lakukan'''


#input
draw= int(input("Masukkan jumlah draw:"))

#proses 
jmlh_cmn= draw//(100/70)

jmlh_rare= draw//(100/20)

a = jmlh_cmn == 10
x= ["0", "1"] 
y = x[int(a)]
z = int(y) + jmlh_rare

jmlh_spr_rare= draw - jmlh_cmn - jmlh_rare
ttl= jmlh_cmn + jmlh_rare + int(y) + jmlh_spr_rare

#output
print("Banyak karakter common didapatkan :" + str(jmlh_cmn))
print("Banyak karakter rare didapatkan :", end=" ")
print(z)
print("Banyak karakter super rare didapatkan :" + str(jmlh_spr_rare))
print("Tuan Vin mendapat" + " " + str(ttl) + " " + "karakter.")
